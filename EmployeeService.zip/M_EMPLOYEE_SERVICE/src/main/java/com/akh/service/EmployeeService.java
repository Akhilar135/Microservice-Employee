package com.akh.service;

import java.util.List;

import com.akh.entity.EmployeeEntity;
import com.akh.vo.EmployeeDepartmentVO;

public interface EmployeeService {

	public EmployeeEntity createEmployee(EmployeeEntity employeeEntity);
	public List<EmployeeEntity> getAll();
	public EmployeeEntity getOne(Integer empId);
	public List<EmployeeEntity> getByDeptId(Integer deptId);
//	public Object getEmployeeWithDepertmentInfo(Integer empId);
	public EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId);
}

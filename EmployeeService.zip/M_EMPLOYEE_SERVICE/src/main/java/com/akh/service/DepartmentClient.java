package com.akh.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.akh.vo.DepartmentVO;


@FeignClient(url = "http://127.0.0.1:8080",value="Department-Client")
public interface DepartmentClient {

	@GetMapping("/department/byid/{deptId}")
	public DepartmentVO getDepartment(@PathVariable Integer deptId); 
}

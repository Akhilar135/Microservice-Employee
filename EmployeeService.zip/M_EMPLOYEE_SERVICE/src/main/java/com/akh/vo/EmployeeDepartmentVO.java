package com.akh.vo;

import com.akh.entity.EmployeeEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDepartmentVO {
	
	private EmployeeEntity employeeEntity;
	private DepartmentVO departmentVO;
	

}

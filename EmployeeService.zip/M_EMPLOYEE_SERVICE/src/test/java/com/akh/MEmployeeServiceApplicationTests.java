package com.akh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MEmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
